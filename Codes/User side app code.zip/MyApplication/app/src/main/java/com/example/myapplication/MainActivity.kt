package com.example.myapplication

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat


class MainActivity : AppCompatActivity() {
    class Companion {
        companion object {
            const val REQUEST_CALL = 1
        }

    }



    class EmergencyButton: AppCompatActivity() {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)
            val imageCall =
                findViewById<ImageView>(R.id.image_call)
            imageCall.setOnClickListener { makePhoneCall() }
        }

        private fun makePhoneCall() {
            val number = "995"
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CALL_PHONE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CALL_PHONE),
                    com.example.myapplication.MainActivity.Companion.REQUEST_CALL
                )
            } else {
                val dial = "tel:$number"
                startActivity(Intent(Intent.ACTION_CALL, Uri.parse(dial)))
            }
        }

        override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<String>,
            grantResults: IntArray
        ) {
            if (requestCode == com.example.myapplication.MainActivity.Companion.REQUEST_CALL) {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    makePhoneCall()
                } else {
                    Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
                }
            }
        }

        companion object {
            private const val REQUEST_CALL = 1
        }
    }

        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun goToWatson(view: View) {
        val intent = Intent(getPackageManager().getLaunchIntentForPackage("com.example.vmac.WatBot"))
        startActivity(intent)
    }

    fun entrypage(view: View) {
        startActivity(new Intent(MainActivity.this, MyOtherActivity.class));
    }
}