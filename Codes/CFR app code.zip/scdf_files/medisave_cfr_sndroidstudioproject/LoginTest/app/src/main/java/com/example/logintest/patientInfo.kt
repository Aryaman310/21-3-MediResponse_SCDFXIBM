package com.example.logintest

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.AlarmClock.EXTRA_MESSAGE
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.beust.klaxon.Klaxon
import kotlinx.android.synthetic.main.activity_dashboard.*
import org.json.JSONObject
import java.io.StringReader

class patientInfo : AppCompatActivity() {

    lateinit var patientID: String
    lateinit var field_name:TextView
    lateinit var field_age:TextView
    lateinit var field_disease:TextView
    lateinit var field_symptoms:TextView
    lateinit var field_help:TextView
    lateinit var field_attacks:TextView
    lateinit var field_allergies:TextView
    lateinit var field_other_info:TextView
    lateinit var serverip:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patient_info)

        patientID = intent.getStringExtra("EXTRA_MESSAGE").toString()
        serverip = intent.getStringExtra("ip").toString()

        //val sharedPref = this.getPreferences(Context.MODE_PRIVATE) ?: return
        //serverip = sharedPref.getString("ip", "NONE|SET IP ---->").toString()

        fetchDetails()
    }

    fun fetchDetails() {
        field_name = findViewById(R.id.field_name)
        field_age = findViewById(R.id.field_age)
        field_disease = findViewById(R.id.field_disease)
        field_symptoms = findViewById(R.id.field_symptoms)
        field_help = findViewById(R.id.field_help)
        field_attacks = findViewById(R.id.field_attacks)
        field_allergies = findViewById(R.id.field_allergies)
        field_other_info = findViewById(R.id.field_other_info)

        val queue = Volley.newRequestQueue(this)
        val url = serverip + "/cfrfetch/" + patientID

        val stringRequest = object : StringRequest(Request.Method.GET, url,
            Response.Listener<String> { response ->
                val reJson = Klaxon().parseJsonObject(StringReader(response))
                //Toast.makeText(this, reJson.toString(), Toast.LENGTH_SHORT).show()

                field_name.text = reJson["name"].toString()
                field_age.text = reJson["age"].toString()
                field_disease.text = reJson["disease"].toString()
                field_symptoms.text = reJson["symptoms"].toString()
                field_help.text = reJson["help"].toString()
                field_attacks.text = reJson["attacks"].toString()
                field_allergies.text = reJson["allergies"].toString()
                field_other_info.text = reJson["other_info"].toString()
            },
            Response.ErrorListener { Toast.makeText(this, "OOPS", Toast.LENGTH_SHORT).show() })
        {}
        queue.add(stringRequest)
    }
}
