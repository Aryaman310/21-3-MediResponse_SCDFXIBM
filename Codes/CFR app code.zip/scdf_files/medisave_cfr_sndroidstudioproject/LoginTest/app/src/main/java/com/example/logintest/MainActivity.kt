package com.example.logintest

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.AlarmClock.EXTRA_MESSAGE
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.android.volley.*
import com.android.volley.toolbox.Volley
import com.android.volley.toolbox.StringRequest
import com.beust.klaxon.JsonObject
import com.beust.klaxon.Klaxon
import com.beust.klaxon.Parser
import org.json.JSONObject
import java.io.StringReader
import java.net.URL

class MainActivity : AppCompatActivity() {

    lateinit var username:EditText
    lateinit var password:EditText
    lateinit var rememberMe:CheckBox
    lateinit var ip_txt:TextView
    lateinit var serverip:String
    lateinit var ip_edit:EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        username = findViewById(R.id.userID_input)
        password = findViewById(R.id.password_input)
        ip_txt = findViewById(R.id.ip_info_text)
        ip_edit = findViewById(R.id.ip_edit)

        val sharedPref = this.getPreferences(Context.MODE_PRIVATE) ?: return
        val userSaved: String? = sharedPref.getString("username", "User ID")
        val passSaved: String? = sharedPref.getString("password", "Password")
        //serverip = sharedPref.getString("ip", "NONE|SET IP ---->").toString()

        username.setText(userSaved)
        password.setText(passSaved)
    }

    fun tryLogin(view: View) {
        serverip = "http://"+(ip_edit.text.toString())+":8080"
        val queue = Volley.newRequestQueue(this)
        val url = serverip+"/cfrlogin"
        //val url = "http://10.117.154.151:8080/cfrlogin"

        val newJson = JSONObject()
        newJson.put(username.text.toString(),password.text.toString())
        val requestStr = newJson.toString()

        val stringRequest = object: StringRequest(Request.Method.POST, url,
            Response.Listener<String> { response ->
                val reJson = Klaxon().parseJsonObject(StringReader(response))
                //Toast.makeText(this,reJson["reply"].toString(),Toast.LENGTH_SHORT).show()

                if (reJson["reply"] == "pass") {
                    goToDash()
                }
                else {
                    Toast.makeText(this, reJson["error"].toString(), Toast.LENGTH_LONG).show()
                }
            },
            Response.ErrorListener { Toast.makeText(this,"OOPS",Toast.LENGTH_SHORT).show() })
        {
            override fun getBodyContentType(): String {
                return "application/json"
            }

            @Throws(AuthFailureError::class)
            override fun getBody(): ByteArray {
                return requestStr.toByteArray()
            }
        }
        queue.add(stringRequest)
    }


    fun goToDash() {
        rememberMe =  findViewById(R.id.rememberCheck);
        if (rememberMe.isChecked) {
            val sharedPref = this.getPreferences(Context.MODE_PRIVATE) ?: return
            with (sharedPref.edit()) {
                putString("username", username.text.toString())
                putString("password", password.text.toString())
                commit()
            }
        }
        else {
            val sharedPref = this.getPreferences(Context.MODE_PRIVATE) ?: return
            with (sharedPref.edit()) {
                putString("username", "User ID")
                putString("password", "Password")
                commit()
            }
        }
        val intent = Intent(this, QRDash::class.java).apply {
            putExtra("ip", serverip)
        }
        startActivity(intent)
    }

    fun goToSignUp(view:View) {
        serverip = "http://"+(ip_edit.text.toString())+":8080"
        val intent = Intent(this, SignUp::class.java).apply {
            putExtra("ip", serverip)
        }
        startActivity(intent)
    }

}
