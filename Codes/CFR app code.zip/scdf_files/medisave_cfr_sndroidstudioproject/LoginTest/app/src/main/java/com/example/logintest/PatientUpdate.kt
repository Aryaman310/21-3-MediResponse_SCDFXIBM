package com.example.logintest

import android.content.Intent
import android.os.Bundle
import android.provider.AlarmClock
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.beust.klaxon.Klaxon
import org.json.JSONObject
import java.io.StringReader

class PatientUpdate : AppCompatActivity() {

    lateinit var patientID: String
    lateinit var field_id:EditText
    lateinit var field_name: EditText
    lateinit var field_age: EditText
    lateinit var field_disease: EditText
    lateinit var field_symptoms: EditText
    lateinit var field_help: EditText
    lateinit var field_attacks: EditText
    lateinit var field_allergies: EditText
    lateinit var field_other_info: EditText
    lateinit var serverip:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patient_update)

        patientID = intent.getStringExtra("EXTRA_MESSAGE").toString()
        serverip = intent.getStringExtra("ip").toString()

        //Toast.makeText(this, patientID+"  "+serverip, Toast.LENGTH_SHORT).show()

        //val sharedPref = this.getPreferences(Context.MODE_PRIVATE) ?: return
        //serverip = sharedPref.getString("ip", "NONE|SET IP ---->").toString()

        field_id = findViewById(R.id.field_idEdit)
        field_name = findViewById(R.id.field_name)
        field_age = findViewById(R.id.field_age)
        field_disease = findViewById(R.id.field_disease)
        field_symptoms = findViewById(R.id.field_symptoms)
        field_help = findViewById(R.id.field_help)
        field_attacks = findViewById(R.id.field_attacks)
        field_allergies = findViewById(R.id.field_allergies)
        field_other_info = findViewById(R.id.field_other_info)

        fetchDetails()
    }

    fun fetchDetails() {

        val queue = Volley.newRequestQueue(this)
        val url = serverip + "/cfrfetch/" + patientID

        val stringRequest = object : StringRequest(Request.Method.GET, url,
            Response.Listener<String> { response ->
                val reJson = Klaxon().parseJsonObject(StringReader(response))
                //Toast.makeText(this, reJson.toString(), Toast.LENGTH_SHORT).show()

                field_id.setText(reJson["id"].toString())
                field_name.setText(reJson["name"].toString())
                field_age.setText(reJson["age"].toString())
                field_disease.setText(reJson["disease"].toString())
                field_symptoms.setText(reJson["symptoms"].toString())
                field_help.setText(reJson["help"].toString())
                field_attacks.setText(reJson["attacks"].toString())
                field_allergies.setText(reJson["allergies"].toString())
                field_other_info.setText(reJson["other_info"].toString())
            },
            Response.ErrorListener { Toast.makeText(this, "FETCH OOPS", Toast.LENGTH_SHORT).show() })
        {}
        queue.add(stringRequest)
    }

    fun updateDetails(view: View) {
        val queue = Volley.newRequestQueue(this)
        val url = serverip+"/patientupdate"

        val newJson = JSONObject()
        newJson.put("id", field_id.text.toString())
        newJson.put("name", field_name.text.toString())
        newJson.put("age", field_age.text.toString())
        newJson.put("disease", field_disease.text.toString())
        newJson.put("symptoms", field_symptoms.text.toString())
        newJson.put("help", field_help.text.toString())
        newJson.put("attacks", field_attacks.text.toString())
        newJson.put("allergies", field_allergies.text.toString())
        newJson.put("other_info", field_other_info.text.toString())

        val requestStr = newJson.toString()

        val stringRequest = object: StringRequest(Request.Method.POST, url,
            Response.Listener<String> { response ->
                val reJson = Klaxon().parseJsonObject(StringReader(response))
                //Toast.makeText(this,reJson["reply"].toString(),Toast.LENGTH_SHORT).show()

                if (reJson["reply"] == "pass") {
                    goToDetails()
                }
                else {
                    Toast.makeText(this, "NO PASS OOPS", Toast.LENGTH_SHORT).show()
                }
            },
            Response.ErrorListener { Toast.makeText(this,"ERR OOPS",Toast.LENGTH_SHORT).show() })
        {
            override fun getBodyContentType(): String {
                return "application/json"
            }

            @Throws(AuthFailureError::class)
            override fun getBody(): ByteArray {
                return requestStr.toByteArray()
            }
        }
        queue.add(stringRequest)
    }

    fun goToDetails() {
        val intent = Intent(this, patientInfo::class.java).apply {
            putExtra("EXTRA_MESSAGE", field_id.text.toString())
            putExtra("ip", serverip)
        }
        startActivity(intent)
    }
}