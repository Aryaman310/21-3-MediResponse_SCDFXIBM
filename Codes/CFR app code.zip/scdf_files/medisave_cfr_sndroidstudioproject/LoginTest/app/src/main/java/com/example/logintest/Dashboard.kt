package com.example.logintest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.AlarmClock.EXTRA_MESSAGE
import android.view.View
import android.widget.EditText
import android.widget.Toast

class Dashboard : AppCompatActivity() {

    lateinit var patientID:EditText
    lateinit var serverip:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
        serverip = intent.getStringExtra("ip").toString()
    }

    fun goToInfo(view: View) {
        patientID = findViewById(R.id.patient_id)
        val intent = Intent(this, patientInfo::class.java).apply {
            putExtra(EXTRA_MESSAGE, patientID.text.toString())
            putExtra("ip", serverip)
        }
        startActivity(intent)
    }
}
