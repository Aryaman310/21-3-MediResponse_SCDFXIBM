package com.example.logintest

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class ip_config : AppCompatActivity() {

    lateinit var ip_field:EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ip_config)

        val sharedPref = this.getPreferences(Context.MODE_PRIVATE) ?: return
        val serverip: String? = sharedPref.getString("ip", "NONE|SET IP ---->")

        ip_field = findViewById(R.id.ip_field)
        ip_field.setText(serverip)
    }

    fun confirmIP(view: View) {
        val sharedPref = this.getPreferences(Context.MODE_PRIVATE) ?: return
        with (sharedPref.edit()) {
            putString("ip", "http://" + (ip_field.text.toString())+ ":8080")
            commit()
        }
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}
