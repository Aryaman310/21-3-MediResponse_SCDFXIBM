package com.example.logintest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class QRDash extends AppCompatActivity {
    public static EditText textView;
    public static String serverip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q_r_dash);

        Intent intent = getIntent();
        serverip = intent.getStringExtra("ip");


        textView=findViewById(R.id.tvResult);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED)

        {    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 1);

        }
        else {

            //Toast.makeText(this, "Permission Allowed...", Toast.LENGTH_SHORT).show();
        }

    }

    public void btnClicked(View view) {
        Intent intent = new Intent(QRDash.this, QRCam.class);
        intent.putExtra("ip", serverip);
        startActivity(intent);
    }

    public void goToFetch(View view) {
        Intent intent = new Intent(QRDash.this, patientInfo.class);
        intent.putExtra("EXTRA_MESSAGE", textView.getText().toString());
        intent.putExtra("ip", serverip);
        startActivity(intent);
    }

    public void goToUpdate(View view) {
        Intent intent = new Intent(QRDash.this, PatientUpdate.class);
        intent.putExtra("EXTRA_MESSAGE", textView.getText().toString());
        intent.putExtra("ip", serverip);
        startActivity(intent);
    }
}