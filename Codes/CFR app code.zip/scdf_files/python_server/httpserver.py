from http.server import BaseHTTPRequestHandler,HTTPServer
import json
import pickle
import pyodbc 

conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=VIRAJ-PC\SQLEXPRESS;'
                      'Database=scdf;'
                      'Trusted_Connection=yes;')
cursor = conn.cursor()
PORT_NUMBER = 8080

class myHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path=='/':
            self.send_response(200)
            self.end_headers()
            self.wfile.write('Get recieved'.encode())

        elif self.path.split('/')[1]=='cfrfetch':
            patient_id = int(self.path.split('/')[2])
            cursor.execute('select * from for_cfr where id='+str(patient_id)+';')
            try:
                data=cursor.fetchall()[0]
            except IndexError:
                data=['No Records' for x in range(9)]
            template=['id','name','age','disease','symptoms','attacks','allergies','other_info','help']
            outf={}
            for i in range(len(template)):
                outf[template[i]]=data[i]
            outJ= json.dumps(outf)
            self.send_response(200)
            self.end_headers()
            self.wfile.write(outJ.encode())

    def do_POST(self):
        if self.path=='/cfrlogin':
            content_length = int(self.headers['Content-Length'])
            f=self.rfile.read(content_length)
            fs=f.decode()
            fDict=json.loads(fs)
            fp = open('cfr.p', 'rb')
            cfr = pickle.load(fp)
            try:
                if cfr[list(fDict.keys())[0]]==list(fDict.values())[0]:
                    response = {"reply":"pass"}
                    rJ= json.dumps(response)
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(rJ.encode())
                else:
                    response = {"reply":"fail","error":"incorrect password"}
                    rJ= json.dumps(response)
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(rJ.encode())
            except KeyError:
                response = {"reply":"fail","error":"user doesnt exist"}
                rJ= json.dumps(response)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(rJ.encode())

        elif self.path=='/cfrsignup':
            fr = open('cfr.p','rb')
            cfr= pickle.load(fr)
            fr.close()

            content_length = int(self.headers['Content-Length'])
            f=self.rfile.read(content_length)
            fs=f.decode()
            fDict=json.loads(fs)
            
            if list(fDict.keys())[0] in cfr.keys():
                response = {"reply":"fail","error":"user already exists"}
                rJ= json.dumps(response)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(rJ.encode())
            else:
                cfr[list(fDict.keys())[0]] = list(fDict.values())[0]
                with open('cfr.p', 'wb') as fp:
                    pickle.dump(cfr, fp, protocol=pickle.HIGHEST_PROTOCOL)
                response = {"reply":"pass"}
                rJ= json.dumps(response)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(rJ.encode())

        elif self.path=='/patientlogin':
            content_length = int(self.headers['Content-Length'])
            f=self.rfile.read(content_length)
            fs=f.decode()
            fDict=json.loads(fs)
            fp = open('patients.p', 'rb')
            cfr = pickle.load(fp)
            try:
                if cfr[list(fDict.keys())[0]]==list(fDict.values())[0]:
                    response = {"reply":"pass"}
                    rJ= json.dumps(response)
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(rJ.encode())
                else:
                    response = {"reply":"fail","error":"password"}
                    rJ= json.dumps(response)
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(rJ.encode())
            except KeyError:
                response = {"reply":"fail","error":"id"}
                rJ= json.dumps(response)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(rJ.encode())

        elif self.path=='/patientsignup':
            fr = open('patients.p','rb')
            patients= pickle.load(fr)
            fr.close()

            content_length = int(self.headers['Content-Length'])
            f=self.rfile.read(content_length)
            fs=f.decode()
            fDict=json.loads(fs)
            
            if list(fDict.keys())[0] in patients.keys():
                response = {"reply":"fail","error":"user already exists"}
                rJ= json.dumps(response)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(rJ.encode())
            else:
                patients[list(fDict.keys())[0]] = list(fDict.values())[0]
                with open('patients.p', 'wb') as fp:
                    pickle.dump(patients, fp, protocol=pickle.HIGHEST_PROTOCOL)
                response = {"reply":"pass"}
                rJ= json.dumps(response)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(rJ.encode())

        elif self.path=='/patientupdate':
            content_length = int(self.headers['Content-Length'])
            f=self.rfile.read(content_length)
            fs=f.decode()
            fDict=json.loads(fs)

            cursor.execute('select * from for_cfr where id='+str(fDict['id'])+';')
            data=cursor.fetchall()
            if len(data)==0:
                cursor.execute("insert into for_cfr values ("+str(fDict['id'])+",'"+str(fDict['name'])+"','"+str(fDict['age'])+"','"+str(fDict['disease'])+"','"+str(fDict['symptoms'])+"','"+str(fDict['attacks'])+"','"+str(fDict['allergies'])+"','"+str(fDict['other_info'])+"','"+str(fDict['help'])+"');")
                conn.commit()
                response = {"reply":"pass"}
                rJ= json.dumps(response)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(rJ.encode())
            else:
                cursor.execute('delete from for_cfr where id='+str(fDict['id'])+';')
                conn.commit()
                cursor.execute("insert into for_cfr values ("+str(fDict['id'])+",'"+str(fDict['name'])+"','"+str(fDict['age'])+"','"+str(fDict['disease'])+"','"+str(fDict['symptoms'])+"','"+str(fDict['attacks'])+"','"+str(fDict['allergies'])+"','"+str(fDict['other_info'])+"','"+str(fDict['help'])+"');")
                conn.commit()
                response = {"reply":"pass"}
                rJ= json.dumps(response)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(rJ.encode())
            

try:
	server = HTTPServer(('10.117.154.151', PORT_NUMBER), myHandler)
	print ('Started httpserver on port ' , PORT_NUMBER)
	server.serve_forever()

except KeyboardInterrupt:
	print ('^C received, shutting down the web server')
	server.socket.close()
